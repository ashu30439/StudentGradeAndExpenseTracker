
import grade.GradeCalculator;
import expense.Expense;
import expense.ExpenseManager;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Grade calculation
        System.out.print("Enter student score: ");
        double score = scanner.nextDouble();
        String grade = GradeCalculator.calculateGrade(score);
        System.out.println("Grade: " + grade);

        // Expense tracking demo
        ExpenseManager manager = new ExpenseManager();
        manager.addExpense(new Expense(1, "Books", 200.0, "2025-05-01"));
        manager.getAllExpenses().forEach(exp -> 
            System.out.println(exp.category + ": $" + exp.amount));
    }
}
