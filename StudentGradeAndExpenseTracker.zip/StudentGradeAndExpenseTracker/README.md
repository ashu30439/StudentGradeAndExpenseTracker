
# StudentGradeAndExpenseTracker

A Java console application that calculates student grades and tracks expenses.

## Features

- Grade calculation based on score
- Expense management (add/view)
- Java CLI-based interface

## Technologies

- Java
- Basic OOP structure

## How to Run

Compile and run using any Java IDE or the following commands:

```bash
javac src/**/*.java
java -cp src Main
```
